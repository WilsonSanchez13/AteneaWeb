# Amor y Amistad en Atenea

Backend migrado de Firebase a **Netlify Functions + Netlify Blobs**. No necesitas
crear ninguna cuenta externa ni pegar credenciales: el almacenamiento vive dentro
de tu propio sitio de Netlify.

## Estructura

```
atenea-site/
├── index.html                     ← tu página, ya conectada a las funciones
├── netlify.toml                   ← le dice a Netlify dónde están las funciones
├── package.json                   ← dependencia @netlify/blobs
└── netlify/functions/
    ├── messages.js                ← muro de mensajes (crear, dar like, comentar, regalitos)
    ├── wishes.js                  ← lista de deseos de regalo
    ├── poll.js                    ← votación "¿Jugamos amigo secreto?"
    └── secret-friends.js          ← inscritos al amigo secreto
```

## Cómo desplegar

**Importante:** las funciones serverless NO se despliegan arrastrando la carpeta
al navegador (ese modo solo sube archivos estáticos). Necesitas usar Git o la
Netlify CLI.

### Opción 1: con GitHub (recomendada)
1. Sube esta carpeta completa a un repositorio de GitHub.
2. En Netlify: **Add new site → Import an existing project** y conecta el repo.
3. Netlify detecta `netlify.toml` automáticamente y despliega tanto el sitio
   como las funciones.

### Opción 2: con Netlify CLI (sin GitHub)
```bash
npm install -g netlify-cli
cd atenea-site
npm install
netlify login
netlify init
netlify deploy --prod
```

## Notas

- Los datos se guardan en un "store" global de Netlify Blobs llamado
  `atenea-data`, así que sobreviven a futuros despliegues.
- No hay actualización en tiempo real como con Firebase: la página consulta
  los datos cada 6 segundos (`setInterval` en `index.html`), así que los
  cambios de otras personas aparecen con un pequeño retraso.
- Es de uso abierto (cualquiera con el link puede escribir), igual que estaba
  planteado originalmente con Firestore en modo de prueba. Si más adelante
  quieres evitar spam, se puede agregar una clave simple o un captcha.
